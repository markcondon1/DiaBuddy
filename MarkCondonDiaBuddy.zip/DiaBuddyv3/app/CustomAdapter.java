public class CustomAdapter {
}
