package edu.cofc.diabuddyv3;

import java.time.LocalDateTime;

public class ReadingData {
    int bloodSugarReading;
    LocalDateTime readingDateTime;

    public ReadingData(int sugar, LocalDateTime timeAndDate)
    {
        bloodSugarReading = sugar;
        readingDateTime = timeAndDate;
    }

    public int getSugar()
    {
        return bloodSugarReading;
    }

    public LocalDateTime getDateAndTime(){
        return readingDateTime;
    }

    public void setSugar(int i)
    {
        bloodSugarReading = i;
    }

    public void setDT(LocalDateTime DT)
    {
        readingDateTime = DT;
    }
}
