package edu.cofc.diabuddyv3


import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import edu.cofc.diabuddyv3.databinding.ActivityMainBinding
import java.time.LocalDateTime
import edu.cofc.diabuddyv3.R
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.*
import kotlin.collections.ArrayList



class ListAdapter(private val context: Context, private val arrayList: ArrayList<ReadingData>) : BaseAdapter(){
    private lateinit var dateRead: TextView
    private lateinit var numReading: TextView

    override fun getCount(): Int {
        return arrayList.size
    }
    override fun getItem(position: Int): Any {
        return position
    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View? {
        var convertView = convertView
        convertView = LayoutInflater.from(context).inflate(R.layout.listview, parent, false)
        dateRead = convertView.findViewById(R.id.dateOfReading)
        numReading = convertView.findViewById(R.id.bloodSugar)

        dateRead.text = arrayList[position].dateAndTime.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT))
        numReading.text = arrayList[position].bloodSugarReading.toString() + " mg/dL"

        if(arrayList[position].bloodSugarReading > 150)
        {
            numReading.setTextColor(Color.YELLOW)
        }
        else if(arrayList[position].bloodSugarReading < 70)
        {
            numReading.setTextColor(Color.RED)
        }
        else
        {
            numReading.setTextColor(Color.GREEN)
        }

        return convertView
    }
}


class MainActivity : AppCompatActivity(), DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private lateinit var binding: ActivityMainBinding

   var newDate = LocalDate.MAX
   var newTime = LocalTime.MAX
    var newSugar = 0

    var userAverage = 0.0
    var userInRange = 0.0
    var userTotalReadings = 0
    var userInRangeReadings = 0
    var userHighRange = 0
    var userLowRange = 0

    var listView: ListView? = null
    var arrayList: ArrayList<ReadingData> = ArrayList()
    var itemsAdapter : ListAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val calendar = Calendar.getInstance()
        var datePickerDialog = DatePickerDialog(this,this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

        var timePickerDialog = TimePickerDialog(this,this,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE), false)


        listView = binding.listView
        itemsAdapter = ListAdapter(this, arrayList)
        listView!!.adapter = itemsAdapter

        binding.addButton.setOnClickListener()
        {
            timePickerDialog.show()
            datePickerDialog.show()
        }

        binding.statsButton.setOnClickListener()
        {
            val intent = Intent(this, StatsScreen::class.java)
            compileData()
            intent.putExtra("statsUserAverage", userAverage)
            intent.putExtra("statsUserInRange", userInRange)
            intent.putExtra("statsUserTotalReadings", userTotalReadings)
            intent.putExtra("statsUserInRangeReadings", userInRangeReadings)
            intent.putExtra("statsUserHigh", userHighRange)
            intent.putExtra("statsUserLow", userLowRange)
            startActivity(intent)
        }

    }

    override fun onDateSet(p0: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        Log.i("Calendar","$year -- $month -- $dayOfMonth")
        newDate = LocalDate.of(year,month+1,dayOfMonth)

    }

    override fun onTimeSet(p0: TimePicker?, hour: Int, minute: Int) {
        Log.i("Calendar","$hour+1 -- $minute")
        newTime = LocalTime.of(hour,minute)

        askForBlood()


    }

    fun askForBlood()
    {
        val dialogLayout =
            layoutInflater.inflate(R.layout.blood_sugar_dialog, null)
        val nameEditText: EditText =
            dialogLayout.findViewById(R.id.sugar_edit_text)

        AlertDialog.Builder(this)
            .setTitle(R.string.name_dialog_title)
            .setView(dialogLayout)
            .setPositiveButton(R.string.done_button) { _, _ ->

                newSugar = Integer.parseInt(nameEditText.text.toString())

                if(newSugar > 0) {
                    arrayList.add(ReadingData(newSugar, LocalDateTime.of(newDate, newTime)))
                    binding.noReadings.visibility = View.GONE
                    binding.listView.invalidateViews()
                }
                else
                {
                    Toast.makeText(this, R.string.bad_blood_reading_error_msg, Toast.LENGTH_LONG).show()
                }
            }

            .show()
    }

    fun compileData()
    {
        var count = 0.0
        var lowCount = 0
        var highCount = 0
        var value = 0.0
        var inRange = 0
        for (data in arrayList)
        {
            value += data.sugar
            count++

            if (data.sugar in 71..149)
            {
                inRange++
            }
            else if (data.sugar > 150)
            {
                highCount++
            }
            else if(data.sugar < 70)
            {
                lowCount++
            }


        }

        userAverage = value / count
        userInRange = (inRange / count) * 100
        Log.i("Calendar","$userInRange")
        userTotalReadings = count.toInt()
        userInRangeReadings = inRange
        userHighRange = highCount
        userLowRange = lowCount

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.app_menu, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val dialogLayoutInfo =
            layoutInflater.inflate(R.layout.info_dialog, null)
        val dialogLayoutSettings =
            layoutInflater.inflate(R.layout.settings_dialog, null)

        val toastNoReadings = Toast.makeText(this, R.string.no_readings_error_msg, Toast.LENGTH_LONG)

        val btnDeleteLast = dialogLayoutSettings.findViewById<Button>(R.id.delete_last)
        val btnDeleteAll = dialogLayoutSettings.findViewById<Button>(R.id.delete_all)

        btnDeleteLast.setOnClickListener()
        {
            if(arrayList.size > 0) {
                AlertDialog.Builder(this)
                    .setTitle(R.string.warning_delete_last_title)
                    .setMessage(R.string.cannot_be_undone)
                    .setPositiveButton(R.string.done_button) { _, _ ->
                        arrayList.removeAt(arrayList.size - 1)
                        binding.listView.invalidateViews()
                        if (arrayList.size == 0)
                        {
                            binding.noReadings.visibility = View.VISIBLE
                        }

                    }
                    .setNegativeButton(R.string.cancel) { _, _ -> }

                    .show()
            }
            else
            {
                toastNoReadings.show()
            }
        }

        btnDeleteAll.setOnClickListener()
        {
            if(arrayList.size > 0) {
                AlertDialog.Builder(this)
                    .setTitle(R.string.warning_delete_all_title)
                    .setMessage(R.string.cannot_be_undone)
                    .setPositiveButton(R.string.done_button) { _, _ ->
                        arrayList.clear()
                        binding.listView.invalidateViews()
                        if (arrayList.size == 0)
                        {
                            binding.noReadings.visibility = View.VISIBLE
                        }
                    }
                    .setNegativeButton(R.string.cancel) { _, _ -> }

                    .show()
            }
            else
            {
                toastNoReadings.show()
            }
        }

        when (id) {
            R.id.info ->

                AlertDialog.Builder(this)
                    .setTitle(R.string.info)
                    .setView(dialogLayoutInfo)
                    .setPositiveButton(R.string.done_button) { _, _ ->

                    }

                    .show()
            R.id.settings ->
                AlertDialog.Builder(this)
                    .setTitle(R.string.settings)
                    .setView(dialogLayoutSettings)
                    .setPositiveButton(R.string.done_button) { _, _ ->

                    }

                    .show()

        }
        return super.onOptionsItemSelected(item)

}
}