package edu.cofc.diabuddyv3

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import edu.cofc.diabuddyv3.databinding.ActivityStatsScreenBinding


class StatsScreen : AppCompatActivity() {
    private lateinit var binding: ActivityStatsScreenBinding


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats_screen)
        binding = ActivityStatsScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var pieChart = binding.pieChart



        val userAverage = intent.getDoubleExtra("statsUserAverage", 0.0)
        val userInRange = intent.getDoubleExtra("statsUserInRange", 0.0)
        val userTotalReadings = intent.getIntExtra("statsUserTotalReadings", 0)
        val userInRangeReadings = intent.getIntExtra("statsUserInRangeReadings", 0)
        val userHighReadings = intent.getIntExtra("statsUserHigh", 0)
        val userLowReadings = intent.getIntExtra("statsUserLow", 0)


        val averageText = String.format("%.2f", (userAverage))
        val inRangeText = String.format("%.2f", userInRange)

        val colors: ArrayList<Int> = ArrayList()
        if(userLowReadings > 0) {
            colors.add(Color.RED)
        }
        if (userHighReadings > 0) {
            colors.add(Color.YELLOW)
        }
        if(userInRangeReadings > 0) {
            colors.add(Color.GREEN)
        }


        val pieEntries: ArrayList<PieEntry> = ArrayList()
        val label = ""

        val typeAmountMap: HashMap<String, Int> = HashMap<String, Int> ()
        typeAmountMap.put("In Range", userInRangeReadings)
        typeAmountMap.put("Above Range", userHighReadings)
        typeAmountMap.put("Below Range", userLowReadings)

        for (type in typeAmountMap.keys) {
            pieEntries.add(PieEntry(typeAmountMap[type]!!.toFloat(), type))
        }

        val pieDataSet = PieDataSet(pieEntries, label)
        pieDataSet.setValueTextSize(12f)
        pieDataSet.setColors(colors)
        val pieData = PieData(pieDataSet)
        pieData.setDrawValues(true)

        pieChart.isDrawHoleEnabled = false
        pieChart.setData(pieData)
        pieChart.getDescription().setEnabled(false)

        pieChart.setTransparentCircleAlpha(255)
        pieChart.invalidate()

        if(userAverage > 0){
            binding.averageNum.text = averageText + " mg/dL"
            binding.timeInRange.text = inRangeText + "%"
            binding.howMany.text = "Out of $userTotalReadings readings, you were in range for $userInRangeReadings out of $userTotalReadings."
        }
        else
        {
            binding.averageNum.text = "0 mg/dL"
            binding.timeInRange.text = "0%"
            binding.howMany.text = "You have no readings."
            binding.tips.text = "Add a reading by clicking the Add button on the main screen."
        }

        if(userAverage > 150)
        {
            binding.averageNum.setTextColor(Color.YELLOW)
            binding.tips.setText(R.string.high_average)
        }
        else if(userAverage < 70)
        {
            binding.averageNum.setTextColor(Color.RED)
            binding.tips.setText(R.string.low_average)
        }
        else if(userAverage > 0)
        {
            binding.averageNum.setTextColor(Color.GREEN)
            binding.tips.setText(R.string.good_average)
        }

        binding.returnButton.setOnClickListener()
        {
            finish()
        }
    }
}